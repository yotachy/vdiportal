# Handoff: 정성인연 자산관리 (vdi-log/up.html) 리디자인 — "모던 핀테크" 방향

## Overview
yotachy/vdiportal 저장소의 `vdi-log/up.html`(단일 파일 개인 자산관리 대시보드)의 시각 리디자인.
사용자가 3개 방향 중 **1b "모던 핀테크"**(밝은 화이트 카드 + 네이비/골드 브랜드 유지)를 선택했고,
대시보드·자산 목록·자산 추가/수정 시트까지 전체 플로우 시안이 포함됨.

## About the Design Files
이 번들의 `정성인연 자산관리 개선.dc.html`은 **HTML로 제작된 디자인 레퍼런스(정적 시안)**입니다.
그대로 배포할 코드가 아니라, **기존 `up.html`의 구조(바닐라 JS + 단일 파일, localStorage 데이터, FX/시세 동기화 로직)를 유지한 채
이 시안의 룩앤필로 재구현**하는 것이 과제입니다. 기존 기능 로직은 전부 보존하고 마크업/CSS만 교체하는 접근을 권장.

시안 파일 구조: 캔버스 문서 안에 옵션들이 섹션으로 배치됨.
- `#1b` — 선택된 대시보드 방향 (데스크톱 960px + 모바일 390px 프레임)
- `#2a` — 자산 목록 (데스크톱 + 모바일)
- `#2b` — 자산 추가/수정 시트 (데스크톱 모달 + 모바일 풀시트)
- `#1a`, `#1c` — 탈락한 대안 (참고용, 구현 대상 아님)

## Fidelity
**High-fidelity.** 색·타이포·간격·라운드·그림자 값이 최종 의도값. 데이터(₩434,340,000 등)는 데모용 —
실제 값은 기존 localStorage 데이터에서 렌더링.

## Screens / Views

### 1. 대시보드 (#1b)
**Purpose**: 총자산·전월 대비·자산 배분을 한눈에.
**Layout (desktop)**: 상단 헤더 60px → 콘텐츠 padding 24-26px → 2열 그리드 `1.15fr 1fr, gap 18px`(히어로 카드 | 도넛 카드) → "보유 자산" 리스트 카드.
- **헤더**: 흰 배경, `border-bottom 1px #eaeef4`. 로고 칩 30×30 radius 9px, bg `#2b3a55`, 글자 `#f5b500` "정". 타이틀 `.9rem/800 #1c2430`. 우측: 환율 pill (`.72rem #8a94a3`, bg `#f2f5f9`, radius 999px, padding 6px 12px).
- **히어로 카드**: `linear-gradient(135deg,#2b3a55,#3a4d70)`, radius 20px, padding 24-26px, 흰 글자. 우상단 장식: radial-gradient 골드 글로우 원. "총 자산" `.76rem/700 #c4cddc` → 금액 `2.5rem/800, letter-spacing -.03em, tabular-nums` → 한글 표기 `.88rem/700 #f5b500`. 하단 스탯 2개(전월 대비 `#8fe6c3`, 자산 수) 세로 구분선 `rgba(255,255,255,.18)`.
- **도넛 카드**: 흰 bg, radius 20px, shadow `0 1px 3px rgba(20,26,40,.05), 0 12px 30px rgba(20,26,40,.05)`. 도넛 140px `conic-gradient`(분류색), 중앙 흰 원(inset 20px)에 최대 비중 표시. 우측 범례: 컬러닷 8px + 분류명 + %.
- **보유 자산 리스트**: 카드 radius 18px, 행 `flex, gap 13px, padding 14px 18px`, 구분선 `1px #f1f4f8`. 행 구성: 아이콘 칩 38×38 radius 11px(분류색 연한 bg + 진한 글자, 예: 부동산 `#fbeaea`/`#c0392b`) + 항목명 `.86rem/800` + 메타 `.72rem #8a94a3` + 우측 금액 `.92rem/800 tabular-nums` + 등락(`#0f8a6d` 상승 / `#c0392b` 하락).
**Layout (mobile 390px)**: 히어로 카드(radius 22px) → 도넛 158px 중앙 → 자산 카드 리스트(radius 15px, gap 9px) → 하단 고정 "＋ 자산 추가" 바(height 52px, radius 16px, bg `#2b3a55`, 글자 `#f5b500`).

### 2. 자산 목록 (#2a)
**Purpose**: 전체 자산 탐색·검색·필터·편집 진입.
**Layout (desktop)**: 페이지 타이틀 `1.3rem/800` + 부제 → 우측 검색 인풋(230px, height 40px, radius 11px, border `1px #e3e9f1`) + "＋ 자산 추가" 버튼(height 40px, radius 11px, bg `#f5b500`, 글자 `#211a05`, shadow `0 2px 8px rgba(245,181,0,.3)`).
- **필터 칩**: radius 999px, 선택 `bg #2b3a55/글자 #fff`, 비선택 `bg #fff, border 1px #e3e9f1, 글자 #4a5568`. 개수 표기 포함("전체 10").
- **분류 그룹 헤더**: 컬러 사각 10px + 분류명 `.82rem/800` + 개수 + 가운데 헤어라인(`1px #eaeef4`) + 우측 소계·비중.
- **행**: 대시보드 리스트와 동일 + 우측 액션 아이콘 2개(편집 ✎ / 삭제 🗑, 30×30 radius 8px, bg `#f4f6fa`; 삭제는 `#c0392b`). 실제 구현에선 hover 시 표시 권장.
**Layout (mobile)**: 상단 고정 헤더(타이틀 + 검색바 height 40px bg `#f4f6fa`) → 가로 스크롤 필터 칩 → 그룹 헤더 + 카드 리스트 → 우하단 FAB 56px 원형 bg `#f5b500`, shadow `0 10px 26px rgba(245,181,0,.42)`. 모바일 편집 진입: 카드 탭 → 시트 열기 (스와이프 액션은 선택 사항).

### 3. 자산 추가/수정 시트 (#2b) — 편집 UX 개선의 핵심
**Purpose**: 기존의 빽빽한 폼을 단계적·조건부 구조로 재편.
**Desktop**: 중앙 모달 460px, radius 22px, shadow `0 30px 70px rgba(20,26,40,.32)`. 딤 배경.
**Mobile**: 풀스크린 시트. 상단 바(취소 | 타이틀) + **하단 고정 저장바**(padding 14-18px, border-top `#f1f4f8`, shadow `0 -6px 20px rgba(20,26,40,.06)`) — 구형 기기(iPhone 11)에서도 저장 버튼이 항상 엄지 범위. 본문 하단 padding 100px로 겹침 방지.
**폼 구성 (순서대로)**:
1. **분류 선택 — 아이콘 세그먼트 그리드** (기존 `<select>` 대체): `grid 4열, gap 7px`. 각 셀: 아이콘 칩(28-30px, 분류색) + 라벨 `.62-.64rem`. 선택 상태: `border 1.5px 분류색 + bg 분류 연한색 + 칩은 진한색 반전`. 비선택: `border 1.5px #eef2f7`.
2. **항목명** 인풋: height 46-50px, radius 12-13px, border `1.5px #e3e9f1`, 글자 `.92rem/700`.
3. **기관 / 이름**: 2열 그리드 gap 10px.
4. **주식 정보 박스 (조건부)**: 국내주식/해외주식/암호화폐 등 시세 분류 선택 시에만 표시. bg `#f7f9fc`, radius 14px, padding 14px. 헤더 "주식 정보 · 시세 자동"(`.7rem/700 #3b6ea5` + 도트). 내부: 보유종목(티커) + 보유수 2열, 현재가(통화 드롭다운 66px + 금액). 내부 인풋: 흰 bg, height 42-46px, radius 10-11px.
5. **평가금액 — 강조 처리**: 라벨 우측 "자동 계산" 배지(`#d99800` on `#fef4dc`, radius 999px; 주식 분류일 때만). 인풋 height 54-58px, **border 1.5px #f5b500, bg #fffdf5**, `₩` 프리픽스 + 금액 `1.35-1.45rem/800 tabular-nums`. 아래 **실시간 한글 표기** `.74rem/700 #d99800` (예: "1,850만원") — 입력과 동시에 갱신.
6. **자산 합계에 포함** 토글: 44×26 pill, on 상태 bg `#f5b500`, 흰 노브 20px.
7. **푸터 버튼**: 취소(outline `1.5px #e3e9f1`, flex 1) + 저장(bg `#f5b500`, 글자 `#211a05`, flex 1.4-1.5, height 50-52px, radius 13-14px, shadow `0 4px 14px rgba(245,181,0,.36)`).

## Interactions & Behavior
- 분류 세그먼트 탭 → 즉시 선택 + 주식 정보 박스 show/hide (150-200ms ease 트랜지션 권장).
- 주식 분류: 평가금액 = 보유수 × 현재가(× 환율) 자동 계산, 읽기전용 스타일. 그 외 분류: 평가금액 직접 입력.
- 금액 입력: 천단위 콤마 자동 포맷 + 아래 한글 만원 단위 실시간 표기.
- 목록: 필터 칩 탭 → 분류 필터, 검색은 항목명·기관·이름 대상 즉시 필터.
- 행 편집 아이콘 → 해당 자산으로 시트 열기. 삭제 → confirm.
- 모바일 시트 저장/취소는 하단 고정 바.
- hover(데스크톱): 리스트 행 bg `#f7f9fc`, 버튼류 살짝 밝게/그림자 강화.

## State Management
기존 up.html의 데이터 모델·localStorage 키·FX/시세 동기화 로직을 그대로 사용. 추가 상태:
- 목록 필터(분류) / 검색어
- 편집 시트: 선택 분류(주식 정보 박스 표시 여부), 계산된 평가금액

## Design Tokens
**Colors**
- Navy(브랜드): `#2b3a55`, 그라데이션 보조 `#3a4d70`
- Gold(액션/강조): `#f5b500`, 골드 텍스트 `#d99800`, 골드 연한 bg `#fef4dc`, 골드 인풋 bg `#fffdf5`, 버튼 글자 `#211a05`
- 텍스트: 주 `#1c2430`, 보조 `#4a5568`, 3차/메타 `#8a94a3`, placeholder `#b3bcc8`
- 배경: 페이지 `#f4f6fa`, 카드 `#fff`, 인풋 회색 `#f7f9fc`/`#f2f5f9`/`#f4f6fa`
- 보더: `#eaeef4`(구분선 굵은), `#f1f4f8`(행 구분선), `#e3e9f1`(인풋), `#eef2f7`(비선택 세그먼트)
- 상승 `#0f8a6d`(카드 내 밝은 버전 `#8fe6c3`), 하락 `#c0392b`
- 분류색 (칩: 연한 bg / 진한 글자): 부동산 `#fbeaea`/`#c0392b` · 퇴직연금 `#f0eafa`/`#6f42c1` · 국내주식 `#e8f0f8`/`#3b6ea5` · 해외주식 `#e6f5f0`/`#0f8a6d` · 현금 `#fbf1de`/`#b06f00` · 암호화폐 `#d99800` · 기타 `#5b6b7c`

**Typography**: Pretendard (`https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.min.css`), fallback system-ui. 금액은 항상 `font-variant-numeric: tabular-nums`. 대표 스케일: 히어로 금액 2.5rem/800, 페이지 타이틀 1.3rem/800, 행 항목명 .86rem/800, 행 금액 .92rem/800, 메타 .72rem, 라벨 .72rem/700.

**Spacing**: 카드 내부 padding 20-26px, 행 padding 13-14px 18px, 그리드 gap 7-18px, 섹션 간 16-26px.
**Radius**: 대형 카드 18-22px, 인풋/버튼 10-14px, pill/칩 999px, 아이콘 칩 9-11px.
**Shadows**: 카드 `0 1px 3px rgba(20,26,40,.05), 0 12px 30px rgba(20,26,40,.05)` · 골드 버튼 `0 4px 14px rgba(245,181,0,.36)` · 모달 `0 30px 70px rgba(20,26,40,.32)` · FAB `0 10px 26px rgba(245,181,0,.42)`.

## Assets
외부 이미지 없음. 아이콘: 분류는 한글 1글자 칩(부/연/국/해/현 등), 검색은 인라인 SVG(원+선). 시안의 ✎/🗑 이모지는 실제 구현 시 SVG 아이콘으로 교체 권장.

## Files
- `정성인연 자산관리 개선.dc.html` — 전체 시안. 브라우저로 열어 `#1b`(대시보드), `#2a`(목록), `#2b`(편집 시트) 참조. `#1a`/`#1c`는 탈락안.
